===Carousel Horizontal Posts Content Slider ===
Contributors: www.backraw.com
Author URI: http://www.backraw.com
Plugin URI: http://www.backraw.com/plugins/carousel-horizontal-posts-content-slider.zip
Tags: wordpress, plugin, tiny carousel,posts slider, slider, content slider, horizontal
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 8.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This plugin create a post slider on the wordpress website. We have option to customize the slider direction.

== Description ==

This is JQuery Carousel library based wordpress horizontal posts content slider.
= Features of this plugin =

*   Easy to customize.
*   Support all browser.
*   Short code available for pages.
*   Hyperlink option to each post.
*   Separate css file to change the style.




== Installation ==	

**Installation Instruction & Configuration**  	

**Method 1**	

[Upload from website admin with ZIP file](http://www.backraw.com)	 	

**Configuration**



== Screenshots ==

1. http://www.backraw.com/plugins/images/screenshot-1.jpg
2. http://www.backraw.com/plugins/images/screenshot-2.jpg
3. http://www.backraw.com/plugins/images/screenshot-3.jpg