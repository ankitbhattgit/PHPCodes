jQuery(document).ready(function($) {

	$("#foo1").carouFredSel({
		auto : false,
		prev : "#foo1_prev",
		next : "#foo1_next"
	});
});