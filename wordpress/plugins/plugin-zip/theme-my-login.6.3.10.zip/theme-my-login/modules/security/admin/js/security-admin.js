jQuery(document).ready( function($) {
	$('table .row-actions .unlock-user').parents('tr').children().css('background-color', '#ffebe8');
} );