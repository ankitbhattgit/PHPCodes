YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "WPP_RETS",
        "WPP_UI",
        "wpp",
        "wpp.overview",
        "wpp.xmli"
    ],
    "modules": [],
    "allModules": []
} };
});